# TaskFlow Pro - Complete Android APK Project Bundle

## How to Build the APK / AAB Bundle:

### Method 1: Using Android Studio (Recommended)
1. Open Android Studio
2. Click "Open" and select the unzipped "TaskFlow-Android-APK-Project" folder
3. Let Gradle sync dependencies automatically (AGP 8.2+, Gradle 8.5)
4. To test on device: Connect Android phone with USB Debugging and click "Run" (Green Play button)
5. To generate Release APK:
   - Go to menu: "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)"
   - APK will be generated at: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Method 2: Command Line (Gradle)
```bash
# Build Debug APK
./gradlew assembleDebug

# Build Release APK
./gradlew assembleRelease

# Build Google Play AAB Bundle
./gradlew bundleRelease
```

## Included Native Android Features:
- Native NotificationChannel & High Priority Push Notifications
- Native Phone Vibration via VibratorManager
- Background wake & network permissions
- Offline standalone assets bundled into assets/www
- Responsive full-screen WebView with hardware acceleration
